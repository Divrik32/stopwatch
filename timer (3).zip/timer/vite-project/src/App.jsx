import { useState } from 'react'
import './App.css'
// import Timer from './components/Timer'
import Stopwatch from './components/Stopwatch'


function App() {

  return (
    <>
    {/* <Timer/> */}
    <Stopwatch/>
    </>
  )
}

export default App
