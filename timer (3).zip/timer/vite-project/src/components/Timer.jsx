import { useState, useEffect } from 'react';

import React from 'react'

const Timer = () => {
    const [timecount,setTimecount]=useState(0)
    const [miniutes,setMinitues]=useState(0)

    var time
     useEffect(()=>{
       time=setInterval(()=>{
        setTimecount(timecount+1)
        if(timecount===59){
          setMinitues(miniutes+1)
          setTimecount(0)
        }
     },1000)

     return ()=> clearInterval(time)
     


    })

    const restart =()=>{
      setTimecount(0);
      setMinitues(0)
    }
    
    const stop =()=>{
      clearInterval(time)
    }
    
  return (
    <div>    
      <div className='timer'>
    <div className='container'>
        <div className='timer_container'>
        <h1>Timer</h1>
        <h1>{miniutes<10? '0'+miniutes:miniutes}:{timecount<10? '0'+timecount:timecount}</h1>
        
        <button className='stop' onClick={stop}>Stop</button>
        <button className='restart' onClick={restart}>Restart</button>
        <button className='resume' onClick={restart}>Restart</button>

        </div>
    </div>
</div></div>
  )
}

export default Timer